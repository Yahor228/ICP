#pragma once

#include <unordered_map>
#include <QJsonObject>
#include <QJsonArray>
#include <QGraphicsWidget>