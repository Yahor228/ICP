#pragma once
#include <QGraphicsItem>

class Timeline : public QGraphicsItem
{
public:
	Timeline();
private:

};