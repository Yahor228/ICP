#pragma once

#define qsl QStringLiteral