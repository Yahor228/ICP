﻿// ICP.cpp: определяет точку входа для приложения.
//

#include <app.h>


int main(int argc, char **argv)
{
	return App{argc, argv}.start();
}
